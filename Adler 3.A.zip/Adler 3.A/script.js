const caixaPrincipal = document.querySelector(".caixa-principal");
const caixaPerguntas = document.querySelector(".caixa-perguntas");
const caixaAlternativas = document.querySelector(".caixa-alternativas");
const caixaResultado = document.querySelector(".caixa-resultado");
const textoResultado = document.querySelector(".texto-resultado");

const perguntas = [
    {
        enunciado: "Você se depara com a proposta de um Colégio Cívico-Militar no Paraná. Qual é sua primeira reação?",
        alternativas: [
            {
                texto: "Isso é uma ótima ideia!",
                afirmacao: "Acredito que essa abordagem pode melhorar a disciplina e o ensino."
            },
            {
                texto: "Não estou seguro sobre isso.",
                afirmacao: "Preocupo-me com a militarização do ambiente escolar."
            }
        ]
    },
    {
        enunciado: "Ao entrar no colégio, você percebe uma rotina diferente, com ênfase em disciplina e civismo. Como você reage?",
        alternativas: [
            {
                texto: "Acho importante ter essa estrutura!",
                afirmacao: "Isso pode ajudar a formar cidadãos mais conscientes."
            },
            {
                texto: "Sinto que a liberdade é restringida.",
                afirmacao: "Prefiro uma abordagem educacional mais flexível."
            }
        ]
    },
    {
        enunciado: "Durante uma aula sobre civismo, o professor discute o papel do cidadão. Como você se posiciona?",
        alternativas: [
            {
                texto: "Defendo que todos devem participar ativamente da sociedade.",
                afirmacao: "Acredito que o engajamento cívico é fundamental para o desenvolvimento do país."
            },
            {
                texto: "Prefiro que as decisões sejam tomadas por especialistas.",
                afirmacao: "Confio mais na liderança dos que têm conhecimento na área."
            }
        ]
    },
    {
        enunciado: "Após um evento cívico na escola, você deve criar um projeto que reflita a importância do civismo. O que você faz?",
        alternativas: [
            {
                texto: "Crio um projeto em grupo para incentivar o voluntariado.",
                afirmacao: "Acredito que ajudar a comunidade é uma forma de praticar civismo."
            },
            {
                texto: "Desenvolvo uma apresentação sobre a história do civismo no Brasil.",
                afirmacao: "Acho importante entender de onde viemos para saber para onde ir."
            }
        ]
    },
    {
        enunciado: "Você e seus colegas estão organizando um debate sobre a relevância dos colégios cívico-militares. Qual é sua postura?",
        alternativas: [
            {
                texto: "Defendo que essa abordagem é positiva e necessária.",
                afirmacao: "Vejo que os colégios cívico-militares podem trazer benefícios significativos para a educação."
            },
            {
                texto: "Acredito que isso não é a solução para os problemas educacionais.",
                afirmacao: "Prefiro discutir alternativas mais inclusivas e menos rígidas."
            }
        ]
    },
];

let atual = 0;
let historiaFinal = "";

function mostraPergunta() {
    if (atual >= perguntas.length) {
        mostraResultado();
        return;
    }
    const perguntaAtual = perguntas[atual];
    caixaPerguntas.textContent = perguntaAtual.enunciado;
    caixaAlternativas.innerHTML = "";
    mostraAlternativas(perguntaAtual.alternativas);
}

function mostraAlternativas(alternativas) {
    alternativas.forEach(alternativa => {
        const botao = document.createElement("button");
        botao.textContent = alternativa.texto;
        botao.addEventListener("click", () => respostaSelecionada(alternativa));
        caixaAlternativas.appendChild(botao);
    });
}

function respostaSelecionada(opcaoSelecionada) {
    historiaFinal += opcaoSelecionada.afirmacao + " ";
    atual++;
    mostraPergunta();
}

function mostraResultado() {
    caixaPerguntas.textContent = "Reflexões sobre o Colégio Cívico-Militar...";
    textoResultado.textContent = historiaFinal;
    caixaAlternativas.innerHTML = "";
}

mostraPergunta();
